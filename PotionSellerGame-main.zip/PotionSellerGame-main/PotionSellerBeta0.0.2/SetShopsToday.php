<?php

include('ConnectTo_DB.php');

try 
{
    $dbh = new PDO('mysql:host='. $hostname .';dbname='. $database, $username, $password);
    $dbh->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $dbh->beginTransaction();
    
    $_usuario = $_POST['usuario'];
    $_array = $_POST['array'];
    
    $sth = $dbh->prepare('SELECT * FROM `ShopsToday` WHERE `WalletAddress` = :usuario');
    $sth->bindParam(':usuario', $_usuario, PDO::PARAM_STR);
    $sth->execute(); 

    $sth->setFetchMode(PDO::FETCH_ASSOC); 
    $result = $sth->fetchAll();
    
    if (count($result) > 0) 
    {
        echo 'existe!';
        if ( $_array == null) $_array = NULL;
        $sth = $dbh->prepare('UPDATE `ShopsToday` SET `Shops` = :array WHERE WalletAddress = :usuario');
        $sth->bindParam(':array', $_array, PDO::PARAM_STR);
        $sth->bindParam(':usuario', $_usuario, PDO::PARAM_STR);
        $sth->execute();
    }
    else
    {
        $sql = 'INSERT INTO `ShopsToday`( `WalletAddress`, `Shops`) VALUES (:usuario,:array)';
        $sth->bindParam(':usuario', $_usuario, PDO::PARAM_STR);
        $sth->bindParam(':array', $_array, PDO::PARAM_STR);
        $sth->execute();

        $new = $dbh->lastInsertId();     
        if ($new > 0) { echo "Done succesfully"; }
    }
    $dbh->commit();
    echo count($result);
}
catch(PDOException $e)
{
	echo "Error: " . $e->getMessage();
}
   
?>

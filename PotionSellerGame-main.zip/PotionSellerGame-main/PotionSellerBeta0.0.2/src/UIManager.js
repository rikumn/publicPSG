function Indexlogged(){
    document.getElementById("Btn_oracle").removeAttribute("readonly");
    document.getElementById("Btn_oracle").removeAttribute("disabled");
    
    document.getElementById("Btn_ingredients").removeAttribute("readonly");
    document.getElementById("Btn_ingredients").removeAttribute("disabled");
    
    document.getElementById("Btn_inventory").removeAttribute("readonly");
    document.getElementById("Btn_inventory").removeAttribute("disabled");
}

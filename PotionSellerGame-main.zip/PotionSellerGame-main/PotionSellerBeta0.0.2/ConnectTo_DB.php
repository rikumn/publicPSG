<?php
    $hostname = 'localhost';
    $username = 'u873188724_admin';
    $password = '6543C4R1Pt0W!S4R564?';
    $database = 'u873188724_criptowizard';

    $dbh = new PDO('mysql:host='. $hostname .';dbname='. $database, $username, $password);
?>